<?php

declare(strict_types=1);

$basePath = __DIR__;

// The built-in PHP server uses this file as its router; Apache uses .htaccess.
if (PHP_SAPI === 'cli-server') {
    $path = rawurldecode((string) (parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/'));
    if (preg_match('#(^|/)\.|^/(app|src|config|templates|storage|database|docs|tests|tools|bin|docker|public)(/|$)|^/(config\.php|composer\.(json|lock)|README\.md|Dockerfile|docker-compose\.ya?ml)$#i', $path) === 1) {
        http_response_code(404);
        header('Content-Type: text/plain; charset=utf-8');
        echo 'Not found';
        return;
    }

    if ((str_starts_with($path, '/assets/') || $path === '/favicon.ico') && is_file($basePath . $path)) {
        return false;
    }
}

require_once $basePath . '/app/src/Support/helpers.php';
require_once $basePath . '/app/src/Support/Autoloader.php';

\App\Support\Autoloader::register($basePath . '/app');

$isDebug = false;

set_error_handler(function (int $severity, string $message, string $file, int $line): bool {
    if (!(error_reporting() & $severity)) {
        return false;
    }

    throw new \ErrorException($message, 0, $severity, $file, $line);
});

set_exception_handler(function (\Throwable $throwable) use (&$isDebug): void {
    error_log('[Account+] ' . $throwable::class . ': ' . $throwable->getMessage() . ' in ' . $throwable->getFile() . ':' . $throwable->getLine());

    http_response_code(500);

    if ($isDebug) {
        header('Content-Type: text/plain; charset=utf-8');
        echo $throwable::class . ': ' . $throwable->getMessage() . "\n\n" . $throwable->getTraceAsString();

        return;
    }

    header('Content-Type: text/html; charset=utf-8');
    echo '<h1>500</h1><p>An internal error occurred.</p>';
});

session_name('php_compte');
ini_set('session.use_strict_mode', '1');
ini_set('session.use_only_cookies', '1');
ini_set('session.cookie_httponly', '1');
session_set_cookie_params([
    'path' => '/',
    'httponly' => true,
    'secure' => isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
    'samesite' => 'Lax',
]);
session_start();

header('Content-Security-Policy: default-src \'self\'; script-src \'self\' \'unsafe-inline\'; style-src \'self\' \'unsafe-inline\'; img-src \'self\' data:; object-src \'none\'; base-uri \'self\'; frame-ancestors \'self\'; form-action \'self\'');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: SAMEORIGIN');
header('Referrer-Policy: strict-origin-when-cross-origin');
header('Permissions-Policy: camera=(), microphone=(), geolocation=()');
header('Cache-Control: no-store');

$config = \App\Support\Config::fromBasePath($basePath);
$isDebug = (bool) $config->get('app.debug', false);
ini_set('display_errors', $isDebug ? '1' : '0');
ini_set('error_reporting', (string) E_ALL);

$view = new \App\Support\View($basePath . '/app/templates');
$kernel = new \App\Application\AppKernel($config, $view);
$request = \App\Http\Request::fromGlobals();

$kernel->handle($request)->send();
