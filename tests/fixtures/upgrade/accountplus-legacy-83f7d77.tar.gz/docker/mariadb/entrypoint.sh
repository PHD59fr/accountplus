#!/bin/sh
set -e

DATADIR="/var/lib/mysql"
SOCKET="/run/mysqld/mysqld.sock"
ROOT_PASSWORD="${MYSQL_ROOT_PASSWORD:-root}"
DB_NAME="${MYSQL_DATABASE:-compte}"
DB_USER="${MYSQL_USERNAME:-compte}"
DB_PASSWORD="${MYSQL_PASSWORD:-compte}"

if [ ! -d "$DATADIR/mysql" ]; then
    echo "[MariaDB] Initializing data directory ..."
    mkdir -p "$DATADIR"
    chown -R mysql:mysql "$DATADIR"
    mariadb-install-db --user=mysql --datadir="$DATADIR" --auth-root-authentication-method=normal --skip-test-db

    echo "[MariaDB] Starting temporary server ..."
    mariadbd --user=mysql --datadir="$DATADIR" --socket="$SOCKET" --skip-networking=0 &
    PID=$!

    i=0
    until mariadb-admin ping --socket="$SOCKET" >/dev/null 2>&1; do
        i=$((i + 1))
        if [ "$i" -ge 60 ]; then
            echo "[MariaDB] Temporary server did not start." >&2
            exit 1
        fi
        sleep 1
    done

    echo "[MariaDB] Creating database '${DB_NAME}' and user '${DB_USER}' ..."
    mariadb --socket="$SOCKET" -uroot <<SQL
ALTER USER 'root'@'localhost' IDENTIFIED BY '${ROOT_PASSWORD}';
CREATE DATABASE IF NOT EXISTS \`${DB_NAME}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER IF NOT EXISTS '${DB_USER}'@'%' IDENTIFIED BY '${DB_PASSWORD}';
GRANT ALL PRIVILEGES ON \`${DB_NAME}\`.* TO '${DB_USER}'@'%';
FLUSH PRIVILEGES;
SQL

    mariadb-admin shutdown --socket="$SOCKET" -uroot -p"$ROOT_PASSWORD" >/dev/null 2>&1 || kill "$PID" 2>/dev/null || true
    wait "$PID" 2>/dev/null || true
    echo "[MariaDB] Initialization complete."
fi

exec "$@"
