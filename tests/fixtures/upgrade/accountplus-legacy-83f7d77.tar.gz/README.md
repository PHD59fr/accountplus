# 🚀 **Account+**

**Account+** is a self-hosted, multi-company accounting web application. It lets you manage accounts, transactions, categories and recurring operations per company, while keeping a full audit trail. The project is currently under active development, and contributions are welcome!

🔗 **GitHub Repository**: [https://github.com/phd59fr/accountplus](https://github.com/phd59fr/accountplus)

---

## ✨ **Key Concept - The Archive as the Portable Source of Truth**

In **Account+**, data flows in and out of the application through a **stable, versioned archive format** (`compte-import` / `compte-export`). This means migrations, backups and restores are always predictable and replayable, regardless of the source database or the destination instance.

### How it works:

* **Validation-First Import**:
  Before anything touches the database, the archive is validated: format, version, mandatory entries, line lengths and JSON structure. Import is **transactional**. A failure rolls everything back.

* **Idempotency**:
  Each archive is fingerprinted with its SHA-256. Re-importing the same archive is detected and skipped unless `--force` is used.

* **Replayable Export**:
  Exporting a company produces the same stable format, ready to be imported elsewhere (backup, migration or analysis).

### **Advantages of this Approach**

* **Centralized Data Management**: All data enters and leaves through the same audited pipeline.
* **Enhanced Security**: Archives are validated and imported in one transaction; nothing partial is left behind.
* **State Consistency**: `manifest.json` and per-record warnings/errors give full visibility of every import.
* **Audit and Traceability**: Every import, export and download is recorded in the audit log.
* **Fully Automated Management**: CLI commands (`import:inspect`, `import:run`, `export:run`) make the pipeline scriptable.
* **Easy Exportability**: A full company export is a single versioned archive that can be replayed on a new instance.

---

## 🔍 **Features Overview**

### 👤 **Core Features (End Users)**

| Area                     | Description                                                                  |
|--------------------------|------------------------------------------------------------------------------|
| 📊 **Dashboard**         | Global balance, income, expenses, recent transactions, recurring overview and activity. |
| 🏢 **Companies**         | Create, rename, delete and **select the company workspace** for the current session. Each company keeps its own accounts, categories and transactions. |
| 🏦 **Accounts**          | Bank account inventory with balances and activity counts. Currency, initial balance, bank name, account number, description, archive/restore. |
| 🧾 **Transactions**      | Ledger entries per company: date, value date, label, category, amount, reconciliation status, archive/restore, search and **full change history**. |
| 🗂️ **Categories**        | Hierarchical (parent/child) classification with **emoji**, type (income / expense / transfer), sort order and active state. Cycle detection on parent change. |
| 🔁 **Recurring Rules**    | Automatically post recurring income, expense and transfer entries (daily, weekly, monthly or yearly, with intervals, end date and on/off toggle). |
| 📈 **Reports**           | Transaction report with date / account / category / label filters, category breakdown, opening & closing balances, and **CSV export**. |

### 🦸 **Admin Commands (Manage the Application)**

| Feature                    | Description                                                             |
|----------------------------|-------------------------------------------------------------------------|
| 👥 **Users**               | Create users, promote to **admin**, attach users to companies, activate / deactivate accounts. |
| 📥 **Imports**             | Upload a `compte-import` ZIP and target the company that receives its accounts, transactions and categories. Inspect warnings / errors per import. |
| 📤 **Exports**             | Generate a reusable, versioned `compte-export` ZIP for any company and download it. |
| 🕘 **Audit Log**           | Searchable trace of actions, authentication events and data changes, with filters and details. |
| ⚙️ **Settings**            | Global date format, dashboard visibility and IP restrictions: disabled, whitelist or blacklist, with only one active mode. |

### 🛡️ **Restricted Operations**

| Feature             | Description                                                       |
|---------------------|-------------------------------------------------------------------|
| 🔒 **Setup wizard** | First-run bootstrap: configure DB connection, application name and the initial administrator account. Setup is disabled once users exist; it cannot reset an existing administrator. |
| 🔐 **Login lockout** | Too many failed attempts → temporary lockout. Password hashing via bcrypt. |

---

## 📦 **Data Transfer (Import / Export)**

### 🧩 **Archive Format**

Both import and export use the same stable, versioned ZIP layout:

| Artifact                    | Role                                         |
|-----------------------------|----------------------------------------------|
| `manifest.json`             | Package metadata and versioning              |
| `accounts.ndjson`           | Normalized account records                   |
| `categories.ndjson`         | Normalized categories and themes             |
| `transaction_types.ndjson`  | Normalized transaction type codes            |
| `transactions.ndjson`       | Normalized transaction records               |
| `report.json`               | Warnings and diagnostics                       |

### 🪜 **Import Pipeline**

1. **Prepare the archive**, a versioned ZIP produced by the export feature of Account+ (or of another instance).
2. **Import the package**. Account+ validates the archive and imports it into **one target company**, transactionally, with per-record warnings/errors recorded in `import_errors`.

```sh
# Import the archive into a company
php app/bin/console.php import:run import.zip --company=1
```

### 🧩 **Import details**

- Archives are fingerprinted by **SHA-256**; duplicates are skipped unless `--force` is passed.
- Imports run inside a **single transaction**. On failure everything is rolled back.
- Statuses: `processing`, `completed`, `completed_with_errors`, `failed`.
- New exports preserve paired transfer links through the optional `transfer_legacy_id` field. An incomplete or inconsistent linked transfer causes the import to roll back.
- The `inspect` page (`/admin/data/inspect?id=...`) reviews warnings and errors recorded per import.

### 🗂️ **Export**

Exporting a company writes `<company>-<timestamp>.compte.zip` containing the same stable layout, ready for backup, migration or replay:

```sh
# CLI export
php app/bin/console.php export:run --company=1
```

---

## ⚙️ **Console CLI**

The CLI runs via the PHP binary and does not need a web server:

| Command                                      | Description                                                          |
|----------------------------------------------|----------------------------------------------------------------------|
| `php app/bin/console.php help`               | List available commands.                                             |
| `php app/bin/console.php app:name`           | Print the application name.                                          |
| `php app/bin/console.php recurring:process [reference-date] [--company=<id>]` | Post all due recurring transactions for a reference date. |
| `php app/bin/console.php import:inspect <archive.zip>` | Inspect an archive without touching the database.        |
| `php app/bin/console.php import:run <archive.zip> --company=<id> [--force]` | Import an archive into a company.                   |
| `php app/bin/console.php export:run [--company=<id>]` | Export a company to a `compte-export` ZIP.                 |

---

## 🔐 **Security & Reliability**

* **Passwords** hashed with **bcrypt** (`password_hash` / `password_verify`).
* **Sessions** hardened: strict mode, cookie-only, `HttpOnly`, `Secure` on HTTPS, `SameSite=Lax`, and `session_regenerate_id` on login/logout.
* **CSRF protection** on every POST request (token + constant-time comparison).
* **Security headers** on every response: `Content-Security-Policy`, `X-Content-Type-Options`, `X-Frame-Options`, `Referrer-Policy`, `Permissions-Policy`, `Cache-Control: no-store`.
* **Login lockout** after five failures per username or IP address in 15 minutes, shared across sessions and stored in the database.
* **Audit log** records actions, authentication events and data changes with old/new values, IP and username.
* **Transaction history** gives a per-transaction audit trail (`/transactions/history`).
* **Protected internal files**: the root `index.php` handles application requests. Apache's `.htaccess` blocks direct access to application code, configuration, repository metadata, archives and deployment files, and disables directory listings.
* **Transactional imports**: partial data can never be left behind.

---

## 🌐 **Internationalization**

Account+ is fully translatable. The interface language is stored per user and switchable at runtime:

| Locale   | Language      |
|----------|---------------|
| 🇬🇧 `en` | English       |
| 🇫🇷 `fr` | French        |
| 🇩🇪 `de` | German        |
| 🇪🇸 `es` | Spanish       |
| 🇮🇹 `it` | Italian       |
| 🇵🇹 `pt` | Portuguese    |
| 🇳🇱 `nl` | Dutch         |
| 🇵🇱 `pl` | Polish        |

Translation files live in `app/lang/` (`en.php`, `fr.php`, ...) and can be extended easily.

---

## 📥 **Installation**

### 🐘 Requirements

* **PHP 8.2+** with the PDO **MySQL** driver, `fileinfo`, `zip`, `json`, `session` extensions.
* A **MySQL** (or compatible) server.

### 🛠️ Setup steps

1. Clone the repository:

   ```sh
   git clone https://github.com/phd59fr/accountplus.git
   cd accountplus
   ```

2. Create the database and its user:

   ```sql
   CREATE DATABASE compte CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
   CREATE USER 'compte'@'%' IDENTIFIED BY 'secret';
   GRANT ALL PRIVILEGES ON compte.* TO 'compte'@'%';
   FLUSH PRIVILEGES;
   ```

3. Point your web server document root at the project directory (Apache must enable `mod_rewrite` and allow the root `.htaccess`), or use the built-in PHP server with `index.php` as its router:

   ```sh
   php -S 0.0.0.0:8000 index.php
   ```

4. Open `http://localhost:8000/setup` in your browser. The **setup wizard** creates `app/storage/app/config.php` (application name + database connection) and provisions the initial **administrator** account.

5. Log in, create a company, and start managing accounts and transactions. Admins can attach users to companies and manage imports/exports under **Administration → Data transfer**.

> Migrations run automatically on every request (`app/database/migrations/`). Existing databases are upgraded in place.

### 📦 Deploying to a server (files to copy)

Copy these files to the application directory, then configure the web server document root to that directory:

| Path          | Purpose                                             |
|---------------|-----------------------------------------------------|
| `index.php`   | Front controller (all HTTP requests go through it)  |
| `.htaccess`   | Apache access restrictions and routing to the root `index.php` |
| `assets/`     | CSS and bundled JavaScript assets |
| `app/`        | Application code (`bin`, `config`, `database`, `lang`, `src`, `storage`, `templates`) |
| `app/storage/app/config.php` | Generated by setup; preserve this file when deploying |

Do **not** copy: `tests/`, `.github/`, `README.md`, `.gitignore`.

Alternatively, clean a deployment copy with the script at the project root:

```sh
# Classic PHP/Apache hosting (default mode)
./clean4prod.sh --hosting --dry-run --target /path/to/deployment
./clean4prod.sh --hosting --target /path/to/deployment

# Docker deployment
./clean4prod.sh --docker --dry-run --target /path/to/deployment
./clean4prod.sh --docker --target /path/to/deployment
```

Without `--target`, the script cleans its own directory. It removes tests, project
documentation, Git and editor metadata, including editor swap files at the project
root. `--hosting` is the default: it also removes `Dockerfile`, `docker-compose.yml`,
`.dockerignore`, `docker/` and the Docker-only `app/bin/prepare-apache.php` helper.
Use `--docker` to keep those files. The two modes cannot be combined.
Application code, migrations, CLI commands, third-party licenses, configuration
and all of `app/storage/` are preserved in both modes. `--dry-run` previews the
cleanup without deleting anything. Run cleanup on the deployment copy.

Make sure the web server user can **write** to `app/storage/`, including `app/`, `imports/`, `exports/` and `logs/`. Application source files do not need to be writable.

To edit IP restrictions from **Administration → Settings**, the web server also needs
write access to `.htaccess` and its containing directory for atomic replacement.
You can keep the project directory read-only by making `.htaccess` a symlink to
`app/storage/app/apache.htaccess` and granting write access only to that storage directory.
Copy the root `.htaccess` into that file before creating the symlink. Keep the target
readable by Apache and allow symbolic links in the server configuration.
Docker configures this automatically and persists the rules in the `app_storage` volume.

```sh
# Example: copy to the web server
scp -r index.php .htaccess app assets user@server:/var/www/accountplus/
```

### 🐳 Docker (standalone example)

A lightweight, fully **Alpine-based** standalone stack (Apache + PHP 8.2 + MariaDB) is provided with `Dockerfile` and `docker-compose.yml`:

```sh
# Compose v2
docker compose up -d --build

# Compose v1
docker-compose up -d --build
```

Then open **http://localhost:8080/setup** and fill in the setup form with:

| Field             | Value     |
|-------------------|-----------|
| Database host     | `db`      |
| Database name     | `compte`  |
| Database user     | `compte`  |
| Database password | `compte`  |

The stack is tuned through a `.env` file at the project root (with the defaults already set): `COMPOSE_PROJECT_NAME` (container names are `accountplus_app_1` / `accountplus_db_1`), `MYSQL_DATABASE`, `MYSQL_USERNAME`, `MYSQL_PASSWORD`, `MYSQL_ROOT_PASSWORD`, `APP_PORT`, `APP_URL`, `APP_DEBUG`. The `app_storage` named volume preserves configuration and archives across container recreation. Only `app/storage/` is made writable by the web server.

---

## ⚙️ **Configuration**

Configuration is **file-based**. There is no `.env` parser. Values come from, in order of priority:

1. **`app/storage/app/config.php`**, generated by setup, is the source of truth once installed. A legacy **`config.php` at the project root** is still supported and takes priority if present.
2. **`app/config/app.php`** and **`app/config/database.php`**, default values used when no `config.php` exists yet.
3. **Environment variables**, optional overrides read by the default config files when present (`APP_ENV`, `APP_DEBUG`, `APP_URL`, `DB_HOST`, `DB_PORT`, `DB_DATABASE`, `DB_USERNAME`, `DB_PASSWORD`, `IMPORT_MAX_SIZE`, `IMPORT_TIMEOUT`).

### Upgrading an existing deployment

Back up the database, configuration and `app/storage/` before replacing application files.
For Docker deployments created before `app_storage` existed, copy `/var/www/html/config.php`
and the old container's storage **before recreating it**. Restore the configuration to
`/var/www/html/app/storage/app/config.php` in the new container and restore the archives to
its storage volume; make the files readable by the `apache` user. Existing installations
with a root `config.php` can continue using it outside Docker.

Keep the project directory as the web server document root and deploy the root `.htaccess`.
The next application request applies
migrations 007 (company-scoped import fingerprints) and 008 (shared login lockouts).
Transfer edits, archive changes and deletions now affect both entries; the interface
explains this before those actions. Category, description and reconciliation stay specific
to the selected account. A transfer entry must retain its debit or credit sign.

### `config.php` example (generated by `/setup`)

```php
<?php

declare(strict_types=1);

return [
    'app' => [
        'name' => 'Account+',
        'env' => 'production',
        'debug' => false,
        'url' => 'http://127.0.0.1:8000',
        'session_name' => 'php_compte',
    ],
    'database' => [
        'driver' => 'mysql',
        'host' => '127.0.0.1',
        'port' => 3306,
        'database' => 'compte',
        'username' => 'compte',
        'password' => 'secret',
        'charset' => 'utf8mb4',
    ],
];
```

> **Note:** To change the database connection or application name, edit the existing configuration file directly. Setup cannot reset a database that already contains users. If the file is lost, restore it from backup.

### Dashboard display

In **Administration → Settings → Dashboard elements**, administrators can show or
hide each of these elements independently:

- Global balance.
- Monthly income.
- Monthly expenses.
- Upcoming recurring operations.
- Accounts.
- Recent transactions.
- Category breakdown.
- Type breakdown.
- Label breakdown.

All elements are visible by default. Uncheck an element and save to hide it immediately
for **all users and companies**. Each chart can be toggled separately; the transaction
report keeps its two charts. Unchecking everything shows an empty-dashboard message.
On desktop, label and type breakdowns share a row, with the category breakdown on
its own full-width row below. On smaller screens, the charts are stacked vertically.
Other settings, accounts and transaction data are unaffected.

The label chart groups transactions with the same label, trimming surrounding spaces.
It shows the **ten largest labels** and combines the rest under **Other labels**.
Amounts are summed in absolute value so opposite movements do not cancel each other.
Percentages are relative to all active movements of the selected company, across all
dates. Archived transactions and archived accounts are excluded. Blank labels are shown
as **Unlabelled**. Legends show percentages, and tooltips show full labels, amounts and
percentages. Its visibility is controlled by the **Label breakdown** checkbox.
When enabled with no eligible transactions, the card shows a no-data message instead
of disappearing. If the card is missing, check that the checkbox is enabled, a company
is selected and the latest application files have been deployed.

The selection is stored as the `dashboard_widgets` key in the existing `app_settings`
table and changes are audited. **No new database migration is required.**

### IP restrictions

Administrators can configure two independent lists in **Administration → Settings**.
Select **Disabled**, **Whitelist** (allow only listed addresses), or **Blacklist**
(block listed addresses). Only the selected list is enforced; both lists remain saved.
Each list accepts up to 256 IPv4 addresses, IPv6 addresses or CIDR networks, one per line.
An active list cannot be empty, and a change that would block the administrator's current
IP is rejected. Changes are recorded in the audit log.

Rules are written directly into the root `.htaccess`, between
`# BEGIN ACCOUNTPLUS IP RESTRICTIONS` and `# END ACCOUNTPLUS IP RESTRICTIONS`.
All other rules are preserved. Apache 2.4 with `mod_authz_core`, `mod_authz_host` and
`AllowOverride AuthConfig` (included in `AllowOverride All`) enforces the rules immediately
for the entire site, including static assets. The built-in PHP server does not enforce
`.htaccess` IP restrictions.

The displayed client IP comes from `REMOTE_ADDR`. Forwarded headers are not trusted by
the application. Behind a reverse proxy, configure Apache's trusted proxy handling first
so the displayed IP and Apache's IP authorization refer to the same client.

For emergency recovery, remove the complete marked block from `.htaccess` (or its
symlink target); this disables IP restrictions and clears both lists. Back up the file
before deployment. In Docker, only the managed block is carried over from the persistent
file when rebuilding `.htaccess` from the current image's routing and security rules.

---

## 🗂️ **Project Structure**

```
app/
├── bin/console.php            # CLI entry point
├── config/                    # app.php, database.php
├── database/migrations/       # versioned schema migrations
├── lang/                      # translation files (en, fr, de, es, it, nl, pl, pt)
├── src/
│   ├── Application/           # kernel wiring all routes and services
│   ├── Controller/            # HTTP controllers
│   ├── Domain/                # domain models (Company, User)
│   ├── Http/                  # Request, Response, Router
│   ├── Import/                # (import support)
│   ├── Repository/            # data access
│   ├── Security/              # (security support)
│   ├── Service/               # business logic (Auth, Import, Export, Recurring, ...)
│   └── Support/               # Config, Database, View, Migrator, Translator, Archive
├── storage/                   # imports, exports, analysis, logs (git-ignored)
├── templates/                 # views (accounts, admin, auth, categories, ...)
index.php                      # web entry point at the project root
.htaccess                      # Apache access restrictions and routing
assets/                        # CSS and bundled JavaScript assets
tests/                         # lightweight PHP unit tests
```

The architecture is **dependency-light and framework-free**: a simple `Autoloader`, a plain `Router`, PDO-based repositories and services that stay easy to test. There is no external PHP dependency. `composer` is not required.

Charts use the bundled Chart.js 4.4.1 distribution in `assets/vendor/chart.js/`,
including its MIT license. It is served locally so the application works without a CDN
and retains its `script-src 'self'` Content Security Policy.

---

## 🧪 **Testing**

Tests are dependency-free and do not require a MySQL server (pure PHP logic: archive I/O, date math, import parsing).

```sh
# PHP unit tests
php tests/run.php

# CI (GitHub Actions) also runs PHP syntax checks:
find app tests -name '*.php' -print0 | xargs -0 -n1 php -l
```

The integration suite verifies schema upgrades, administrator protection, manual entries,
archived balances, paired transfer mutations (including rollback on a database failure),
export/import references and per-company fingerprints, and shared login lockouts.
It requires PDO MySQL and an **empty, dedicated** database whose name starts with `accountplus_test`:

```sh
TEST_DB_HOST=127.0.0.1 TEST_DB_DATABASE=accountplus_test \
TEST_DB_USERNAME=compte TEST_DB_PASSWORD=compte php tests/Integration/run.php
```

CI runs both suites against MariaDB.

For a local Web deployment seeded by the integration suite, run
`python3 tests/Integration/web_check.py --url http://127.0.0.1:8080`.
Use `--missing-config` to check that a populated database cannot be reinstalled when
its configuration is absent. The browser fixture `tests/Integration/charts.html` can
be copied into the **test deployment only** as `chart-check.html` at the project root; it logs into
the test account, selects the seeded company and reports `PASS` only when both charts
contain rendered pixels under the application CSP.

---

## 📝 **Current Status**

The project is in **active development**. Planned / in-progress work includes:

- More report views and charting.

---

## 🤝 **Contributing**

Contributions are what make the open-source community such an amazing place to learn, inspire, and create. Any contributions you make are **greatly appreciated**.
Here’s how you can help:

* Report bugs
* Suggest features
* Submit pull requests

To contribute:

1. Fork the project
2. Create a new branch (`git checkout -b feature/YourFeature`)
3. Commit your changes (`git commit -m 'Add YourFeature'`)
4. Push to the branch (`git push origin feature/YourFeature`)
5. Open a pull request

---

## 📄 **License**

This project is licensed under the [MIT License](https://opensource.org/licenses/MIT).

---

## ❤️ Support

A simple star on this project repo is enough to keep me motivated for days. If you’re excited about this project, let me know with a tweet.
If you have any questions, feel free to reach out to me on [X](https://x.com/xxPHDxx).
