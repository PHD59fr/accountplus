<?php

declare(strict_types=1);

namespace App\Http;

final class Request
{
    /**
     * @param array<string, mixed> $query
     * @param array<string, mixed> $request
     * @param array<string, array<string, mixed>> $files
     * @param array<string, string> $server
     */
    public function __construct(
        private string $method,
        private string $path,
        private array $query,
        private array $request,
        private array $files,
        private array $server
    ) {
    }

    public static function fromGlobals(): self
    {
        $method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
        $uri = $_SERVER['REQUEST_URI'] ?? '/';
        $path = parse_url($uri, PHP_URL_PATH) ?: '/';

        /** @var array<string, mixed> $query */
        $query = $_GET;
        /** @var array<string, mixed> $request */
        $request = $_POST;
        /** @var array<string, array<string, mixed>> $files */
        $files = $_FILES ?? [];
        /** @var array<string, string> $server */
        $server = $_SERVER;

        return new self($method, $path, $query, $request, $files, $server);
    }

    public function method(): string
    {
        return $this->method;
    }

    public function path(): string
    {
        return $this->path;
    }

    /**
     * @param mixed $default
     * @return mixed
     */
    public function input(string $key, $default = null)
    {
        return $this->request[$key] ?? $this->query[$key] ?? $default;
    }

    public function server(string $key, string $default = ''): string
    {
        return $this->server[$key] ?? $default;
    }

    /**
     * @return array<string, mixed>|null
     */
    public function file(string $key): ?array
    {
        $file = $this->files[$key] ?? null;
        if (!is_array($file)) {
            return null;
        }

        return $file;
    }
}
