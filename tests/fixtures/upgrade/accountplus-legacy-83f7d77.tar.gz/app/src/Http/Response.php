<?php

declare(strict_types=1);

namespace App\Http;

final class Response
{
    /**
     * @param array<string, string> $headers
     */
    public function __construct(
        private string $content,
        private int $status = 200,
        private array $headers = ['Content-Type' => 'text/html; charset=utf-8']
    ) {
    }

    public static function html(string $content, int $status = 200): self
    {
        return new self($content, $status);
    }

    public static function redirect(string $location, int $status = 302): self
    {
        return new self('', $status, ['Location' => $location]);
    }

    /**
     * Builds a response that forces the browser to download a file.
     *
     * @param array<string, string> $headers
     */
    public static function file(string $content, string $filename, string $contentType = 'application/octet-stream', int $status = 200, array $headers = []): self
    {
        $headers = array_merge([
            'Content-Type' => $contentType,
            'Content-Disposition' => 'attachment; filename="' . rawurlencode($filename) . '"',
            'Content-Length' => (string) strlen($content),
            'X-Content-Type-Options' => 'nosniff',
        ], $headers);

        return new self($content, $status, $headers);
    }

    public function send(): void
    {
        http_response_code($this->status);
        foreach ($this->headers as $name => $value) {
            header($name . ': ' . $value);
        }

        echo $this->content;
    }
}
