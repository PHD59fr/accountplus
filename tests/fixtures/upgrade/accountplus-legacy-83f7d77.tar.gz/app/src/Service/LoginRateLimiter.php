<?php

declare(strict_types=1);

namespace App\Service;

use PDO;

final class LoginRateLimiter
{
    private const MAX_FAILURES = 5;
    private const WINDOW_SECONDS = 900;

    public function __construct(private PDO $pdo)
    {
    }

    /** @return array{authenticated: bool, retry_after: int} */
    public function attempt(string $username, string $ip, callable $authenticate): array
    {
        $this->pdo->exec('DELETE FROM login_attempts WHERE expires_at <= NOW() LIMIT 100');
        $this->pdo->beginTransaction();
        try {
            // Serialize attempts across sessions, including concurrent requests. Acquire
            // both buckets in a stable order to avoid inversions between users and IPs.
            $keys = [$this->userKey($username), $this->ipKey($ip)];
            sort($keys);
            $reserve = $this->pdo->prepare(
                'INSERT INTO login_attempts (attempt_key, failures, expires_at)
                 VALUES (:attempt_key, 0, DATE_ADD(NOW(), INTERVAL ' . self::WINDOW_SECONDS . ' SECOND))
                 ON DUPLICATE KEY UPDATE attempt_key = attempt_key'
            );
            foreach ($keys as $key) {
                $reserve->execute(['attempt_key' => $key]);
            }
            $retryAfter = $this->retryAfter($username, $ip);
            $authenticated = false;
            if ($retryAfter === 0) {
                $authenticated = (bool) $authenticate();
                if ($authenticated) {
                    $this->clearUser($username);
                } else {
                    $this->recordFailure($username, $ip);
                }
            }
            $this->pdo->commit();

            return ['authenticated' => $authenticated, 'retry_after' => $retryAfter];
        } catch (\Throwable $throwable) {
            if ($this->pdo->inTransaction()) {
                $this->pdo->rollBack();
            }
            throw $throwable;
        }
    }

    public function retryAfter(string $username, string $ip): int
    {
        $statement = $this->pdo->prepare(
            'SELECT COALESCE(MAX(TIMESTAMPDIFF(SECOND, NOW(), expires_at)), 0)
             FROM login_attempts
             WHERE attempt_key IN (:user_key, :ip_key) AND failures >= :max_failures AND expires_at > NOW()'
        );
        $statement->execute([
            'user_key' => $this->userKey($username),
            'ip_key' => $this->ipKey($ip),
            'max_failures' => self::MAX_FAILURES,
        ]);

        return max(0, (int) $statement->fetchColumn());
    }

    public function recordFailure(string $username, string $ip): void
    {
        if (!$this->pdo->inTransaction()) {
            $this->pdo->exec('DELETE FROM login_attempts WHERE expires_at <= NOW() LIMIT 100');
        }
        $statement = $this->pdo->prepare(
            'INSERT INTO login_attempts (attempt_key, failures, expires_at)
             VALUES (:attempt_key, 1, DATE_ADD(NOW(), INTERVAL ' . self::WINDOW_SECONDS . ' SECOND))
             ON DUPLICATE KEY UPDATE
                failures = IF(expires_at <= NOW(), 1, failures + 1),
                expires_at = IF(expires_at <= NOW(), DATE_ADD(NOW(), INTERVAL ' . self::WINDOW_SECONDS . ' SECOND), expires_at)'
        );
        foreach ([$this->userKey($username), $this->ipKey($ip)] as $key) {
            $statement->execute(['attempt_key' => $key]);
        }
    }

    public function clearUser(string $username): void
    {
        // A successful login must not erase failures against other users from this IP.
        $this->pdo->prepare('DELETE FROM login_attempts WHERE attempt_key = :attempt_key')
            ->execute(['attempt_key' => $this->userKey($username)]);
    }

    private function userKey(string $username): string
    {
        return hash('sha256', 'user:' . strtolower(trim($username)));
    }

    private function ipKey(string $ip): string
    {
        return hash('sha256', 'ip:' . $ip);
    }
}
